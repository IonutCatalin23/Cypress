describe('Demoblaze Automation Tests', () => {
  beforeEach(() => {
    // Visit the application homepage before each test
    cy.visit('https://www.demoblaze.com/');
  });

  it('should navigate among application pages', () => {
    // Navigate to 'Phones' category
    //cy.contains('Phones').click();
    cy.get('#itemc').click()
    cy.get(':nth-child(1) > .card > .card-block > .card-title > .hrefch').click()

    // Navigate back to homepage
    cy.get('#nava').click();
  });

  it('should add a product from "Laptops" category and place an order', () => {
    // Navigate to 'Laptops' category
    cy.contains('Laptops').click();
    

    // Add a product to the cart
    cy.contains('Sony vaio i5').click();
    cy.contains('Add to cart').click();

    // Verify the product is added to the cart
    cy.get('#cartur').click();
    cy.contains('Sony vaio i5').should('be.visible');

    // Proceed to checkout
    cy.contains('Place Order').click();

    // Fill in the order form
    cy.get('#name').type('John Doe');
    cy.get('#country').type('United States');
    cy.get('#city').type('New York');
    cy.get('#card').type('4242424242424242');
    cy.get('#month').type('05');
    cy.get('#year').type('2025');

    // Submit the order
    cy.contains('Purchase').click();

    // Verify the purchase success message
    cy.contains('Thank you for your purchase!').should('be.visible');
  });

  it('should add and remove products from the cart before submitting the order', () => {
    // Add a product from 'Phones' category
    cy.contains('Phones').click();
    cy.contains('Samsung galaxy s6').click();
    cy.contains('Add to cart').click();

    cy.get('.navbar-brand').click();
    cy.contains('Phones').click();
    cy.contains('Samsung galaxy s7').click();
    cy.contains('Add to cart').click();

    // Add a product from 'Laptops' category
    cy.get('.navbar-brand').click();
    cy.contains('Laptops').click();
    cy.contains('MacBook air').click();
    cy.contains('Add to cart').click();

    // Add a product from 'Monitors' category
    cy.get('.navbar-brand').click();
    cy.contains('Monitors').click();
    cy.contains('Apple monitor 24').click();
    cy.contains('Add to cart').click();

    // Verify the products are added to the cart
    cy.get('#cartur').click();
    cy.contains('Samsung galaxy s7').should('be.visible');
    cy.contains('Samsung galaxy s6').should('be.visible');
    cy.contains('MacBook air').should('be.visible');
    cy.contains('Apple monitor 24').should('be.visible');

    // Remove a product from the cart
    cy.contains('Samsung galaxy s6').parent().find('a').click();

    // Verify the removed product is not in the cart
    cy.contains('Samsung galaxy s6').should('not.exist');

    // Proceed to checkout
    cy.contains('Place Order').click();

    // Fill in the order form
    cy.get('#name').type('John Doe');
    cy.get('#country').type('United States');
    cy.get('#city').type('New York');
    cy.get('#card').type('4242424242424242');
    cy.get('#month').type('05');
    cy.get('#year').type('2025');

    // Submit the order
    cy.contains('Purchase').click();

    // Verify the purchase success message
    cy.contains('Thank you for your purchase!').should('be.visible');

  });

  it('should send a message to Contact', () => {
    // Navigate to 'Contact' page
    cy.get(':nth-child(2) > .nav-link').click();
    

    // Fill in the contact form
    cy.get('#recipient-email').type('example@example.com');
    cy.get('#recipient-name').type('John Doe');
    cy.get('#message-text').type('This is a test message');

    // Submit the contact form
    cy.contains('Send message').click();

    // Verify the success message
    cy.on('window:alert', (str) => {
      expect(str).to.equal(`Thanks for the message!!`)
    }) 
  });
});
